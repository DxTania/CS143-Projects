Note about violate.sql:

First existing id in dataset for Actor is 1
First existing id in dataset for Movie is 2
First existing id in dataset for Director is 16 
